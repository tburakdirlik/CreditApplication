package com.payten.paytencreditproect2.SmsApi;

public interface SmsSender {
    void sendSms(SmsRequest smsRequest);
}
