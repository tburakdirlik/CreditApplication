package com.payten.paytencreditproect2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaytenCreditProect2Application {

    public static void main(String[] args) {
        SpringApplication.run(PaytenCreditProect2Application.class, args);
    }

}
